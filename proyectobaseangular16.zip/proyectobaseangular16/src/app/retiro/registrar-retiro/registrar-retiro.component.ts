import { Component } from '@angular/core';

@Component({
  selector: 'app-registrar-retiro',
  templateUrl: './registrar-retiro.component.html',
  styleUrls: ['./registrar-retiro.component.scss']
})
export class RegistrarRetiroComponent {

}

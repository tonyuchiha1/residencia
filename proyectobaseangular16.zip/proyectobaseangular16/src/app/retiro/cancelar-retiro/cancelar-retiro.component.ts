import { Component } from '@angular/core';

@Component({
  selector: 'app-cancelar-retiro',
  templateUrl: './cancelar-retiro.component.html',
  styleUrls: ['./cancelar-retiro.component.scss']
})
export class CancelarRetiroComponent {

}

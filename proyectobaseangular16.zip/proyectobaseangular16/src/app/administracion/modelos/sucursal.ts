import { Region } from "../servicios/region";


export class Sucursal {
    idSucursal: number | undefined;
    centroCosto: string | undefined;
    nombreSucursal : string | undefined;
    region :Region | undefined;
}

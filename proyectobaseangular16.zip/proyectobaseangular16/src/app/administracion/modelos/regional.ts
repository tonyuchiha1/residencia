export class Regional {
    idRegion :number | undefined;
}

export class Perfil {
    idPerfil: number | undefined;
    nombrePerfil : string | undefined;
    descripcionPerfil: string | undefined;
}

import { Empleado } from "./empleado"

export class Usuario {
    idUsuario:number| undefined
    username:| undefined
    password:| undefined
    estatus:| undefined
    empleado:Empleado=new Empleado
    perfiles:Array<any>=new Array


}

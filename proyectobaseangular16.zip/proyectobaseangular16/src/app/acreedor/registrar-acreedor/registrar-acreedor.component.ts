import { Component } from '@angular/core';

@Component({
  selector: 'app-registrar-acreedor',
  templateUrl: './registrar-acreedor.component.html',
  styleUrls: ['./registrar-acreedor.component.scss']
})
export class RegistrarAcreedorComponent {

}

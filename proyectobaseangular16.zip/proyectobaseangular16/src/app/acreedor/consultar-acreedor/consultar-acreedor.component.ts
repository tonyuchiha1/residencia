import { Component } from '@angular/core';

@Component({
  selector: 'app-consultar-acreedor',
  templateUrl: './consultar-acreedor.component.html',
  styleUrls: ['./consultar-acreedor.component.scss']
})
export class ConsultarAcreedorComponent {

}

export const environment = {
  production: false,
  urlAdmin: "http://200.39.22.86:8081/adminPruebas/api",
  /**
   * URL de la API para la carga de archivos
   */

};
